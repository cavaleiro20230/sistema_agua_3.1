"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { toast } from "@/hooks/use-toast"
import { UserPlus, Edit, Trash2, Mail, Search, UserCheck, UserX, Filter } from "lucide-react"

// Tipos de dados
interface User {
  id: string
  name: string
  email: string
  role: "admin" | "user" | "viewer"
  status: "active" | "pending" | "inactive"
  createdAt: string
  lastLogin?: string
  receiveAlerts: boolean
}

// Dados de exemplo
const mockUsers: User[] = [
  {
    id: "1",
    name: "João Silva",
    email: "joao.silva@exemplo.com",
    role: "admin",
    status: "active",
    createdAt: "2023-10-15",
    lastLogin: "2024-03-06 14:30",
    receiveAlerts: true,
  },
  {
    id: "2",
    name: "Maria Oliveira",
    email: "maria.oliveira@exemplo.com",
    role: "user",
    status: "active",
    createdAt: "2023-11-20",
    lastLogin: "2024-03-05 09:15",
    receiveAlerts: true,
  },
  {
    id: "3",
    name: "Carlos Santos",
    email: "carlos.santos@exemplo.com",
    role: "viewer",
    status: "active",
    createdAt: "2024-01-10",
    lastLogin: "2024-03-04 16:45",
    receiveAlerts: false,
  },
  {
    id: "4",
    name: "Ana Pereira",
    email: "ana.pereira@exemplo.com",
    role: "user",
    status: "pending",
    createdAt: "2024-03-01",
    receiveAlerts: false,
  },
  {
    id: "5",
    name: "Roberto Almeida",
    email: "roberto.almeida@exemplo.com",
    role: "user",
    status: "inactive",
    createdAt: "2023-09-05",
    lastLogin: "2023-12-20 11:30",
    receiveAlerts: false,
  },
]

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [filteredUsers, setFilteredUsers] = useState<User[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isAddUserDialogOpen, setIsAddUserDialogOpen] = useState(false)
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    role: "user",
    receiveAlerts: false,
  })
  const [userToDelete, setUserToDelete] = useState<User | null>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  // Carregar usuários
  useEffect(() => {
    // Em um ambiente real, isso seria uma chamada API
    setUsers(mockUsers)
    setFilteredUsers(mockUsers)
  }, [])

  // Filtrar usuários
  useEffect(() => {
    let result = users

    // Filtrar por termo de busca
    if (searchTerm) {
      result = result.filter(
        (user) =>
          user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          user.email.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filtrar por status
    if (statusFilter !== "all") {
      result = result.filter((user) => user.status === statusFilter)
    }

    setFilteredUsers(result)
  }, [searchTerm, statusFilter, users])

  // Adicionar usuário
  const handleAddUser = () => {
    if (!newUser.name || !newUser.email) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    // Em um ambiente real, isso seria uma chamada API
    const newUserData: User = {
      id: Date.now().toString(),
      name: newUser.name,
      email: newUser.email,
      role: newUser.role as "admin" | "user" | "viewer",
      status: "pending",
      createdAt: new Date().toISOString().split("T")[0],
      receiveAlerts: newUser.receiveAlerts,
    }

    setUsers([...users, newUserData])
    setIsAddUserDialogOpen(false)
    setNewUser({
      name: "",
      email: "",
      role: "user",
      receiveAlerts: false,
    })

    toast({
      title: "Usuário adicionado",
      description: "O usuário foi adicionado com sucesso.",
    })
  }

  // Excluir usuário
  const handleDeleteUser = () => {
    if (!userToDelete) return

    // Em um ambiente real, isso seria uma chamada API
    setUsers(users.filter((user) => user.id !== userToDelete.id))
    setIsDeleteDialogOpen(false)
    setUserToDelete(null)

    toast({
      title: "Usuário excluído",
      description: "O usuário foi excluído com sucesso.",
    })
  }

  // Alternar status do usuário
  const toggleUserStatus = (userId: string) => {
    setUsers(
      users.map((user) => {
        if (user.id === userId) {
          const newStatus = user.status === "active" ? "inactive" : "active"
          return { ...user, status: newStatus }
        }
        return user
      }),
    )

    toast({
      title: "Status alterado",
      description: "O status do usuário foi alterado com sucesso.",
    })
  }

  // Enviar convite
  const sendInvite = (email: string) => {
    toast({
      title: "Convite enviado",
      description: `Um convite foi enviado para ${email}.`,
    })
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Gerenciamento de Usuários</h1>
        <Dialog open={isAddUserDialogOpen} onOpenChange={setIsAddUserDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="h-4 w-4 mr-2" />
              Adicionar Usuário
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Novo Usuário</DialogTitle>
              <DialogDescription>Preencha os dados para adicionar um novo usuário ao sistema.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome</Label>
                <Input
                  id="name"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  placeholder="Nome completo"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  placeholder="email@exemplo.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="role">Função</Label>
                <select
                  id="role"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  value={newUser.role}
                  onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                >
                  <option value="admin">Administrador</option>
                  <option value="user">Usuário</option>
                  <option value="viewer">Visualizador</option>
                </select>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="receive-alerts"
                  checked={newUser.receiveAlerts}
                  onCheckedChange={(checked) => setNewUser({ ...newUser, receiveAlerts: checked })}
                />
                <Label htmlFor="receive-alerts">Receber alertas por email</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddUserDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleAddUser}>Adicionar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <TabsList>
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="active">Ativos</TabsTrigger>
            <TabsTrigger value="pending">Pendentes</TabsTrigger>
            <TabsTrigger value="inactive">Inativos</TabsTrigger>
          </TabsList>
          <div className="flex gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar usuários..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Função</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Alertas</TableHead>
                    <TableHead>Último Acesso</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.length > 0 ? (
                    filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          {user.role === "admin" && "Administrador"}
                          {user.role === "user" && "Usuário"}
                          {user.role === "viewer" && "Visualizador"}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              user.status === "active"
                                ? "success"
                                : user.status === "pending"
                                  ? "warning"
                                  : "destructive"
                            }
                          >
                            {user.status === "active" && "Ativo"}
                            {user.status === "pending" && "Pendente"}
                            {user.status === "inactive" && "Inativo"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {user.receiveAlerts ? (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Ativado
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                              Desativado
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{user.lastLogin || "Nunca"}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {user.status === "pending" && (
                              <Button variant="outline" size="sm" onClick={() => sendInvite(user.email)}>
                                <Mail className="h-4 w-4" />
                              </Button>
                            )}
                            <Button variant="outline" size="sm" onClick={() => toggleUserStatus(user.id)}>
                              {user.status === "active" ? (
                                <UserX className="h-4 w-4" />
                              ) : (
                                <UserCheck className="h-4 w-4" />
                              )}
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setUserToDelete(user)
                                    setIsDeleteDialogOpen(true)
                                  }}
                                >
                                  <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir o usuário {userToDelete?.name}? Esta ação não pode
                                    ser desfeita.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={handleDeleteUser} className="bg-red-500 hover:bg-red-600">
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        Nenhum usuário encontrado
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="active">{/* Conteúdo similar ao "all", mas filtrado para usuários ativos */}</TabsContent>

        <TabsContent value="pending">
          {/* Conteúdo similar ao "all", mas filtrado para usuários pendentes */}
        </TabsContent>

        <TabsContent value="inactive">
          {/* Conteúdo similar ao "all", mas filtrado para usuários inativos */}
        </TabsContent>
      </Tabs>
    </div>
  )
}

