import { NextResponse } from "next/server"
import { database } from "@/lib/firebase"
import { ref, get, set, push } from "firebase/database"

// GET /api/flow-data - Obter dados de fluxo
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const period = searchParams.get("period") || "day" // day, week, month, year
    const limit = Number.parseInt(searchParams.get("limit") || "100")

    // Obter dados do Firebase
    const dataRef = ref(database, "flowData")
    const snapshot = await get(dataRef)

    if (!snapshot.exists()) {
      return NextResponse.json([])
    }

    // Converter para array e filtrar por período
    const now = new Date()
    const data: any[] = []

    snapshot.forEach((childSnapshot) => {
      const entry = {
        id: childSnapshot.key,
        ...childSnapshot.val(),
      }

      // Converter timestamp para Date
      const timestamp = new Date(entry.timestamp)

      // Filtrar por período
      let include = false
      switch (period) {
        case "day":
          include = now.getTime() - timestamp.getTime() <= 24 * 60 * 60 * 1000
          break
        case "week":
          include = now.getTime() - timestamp.getTime() <= 7 * 24 * 60 * 60 * 1000
          break
        case "month":
          include = now.getTime() - timestamp.getTime() <= 30 * 24 * 60 * 60 * 1000
          break
        case "year":
          include = now.getTime() - timestamp.getTime() <= 365 * 24 * 60 * 60 * 1000
          break
        default:
          include = true
      }

      if (include) {
        data.push(entry)
      }
    })

    // Ordenar por timestamp (mais recente primeiro) e limitar
    data.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

    return NextResponse.json(data.slice(0, limit))
  } catch (error) {
    console.error("Erro ao obter dados de fluxo:", error)
    return NextResponse.json({ error: "Falha ao obter dados de fluxo" }, { status: 500 })
  }
}

// POST /api/flow-data - Registrar novos dados de fluxo
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validar dados obrigatórios
    if (data.flowRate === undefined) {
      return NextResponse.json({ error: "Dados de fluxo não fornecidos" }, { status: 400 })
    }

    // Preparar dados para salvar
    const flowData = {
      flowRate: data.flowRate,
      totalVolume: data.totalVolume,
      timestamp: data.timestamp || new Date().toISOString(),
      tankLevels: data.tankLevels || {},
      leakDetected: data.leakDetected || false,
    }

    // Salvar no Firebase
    const dataRef = ref(database, "flowData")
    const newEntryRef = push(dataRef)
    await set(newEntryRef, flowData)

    // Atualizar dados atuais
    await set(ref(database, "currentData"), {
      ...flowData,
      lastUpdated: new Date().toISOString(),
    })

    // Verificar condições de alerta
    await checkAlertConditions(flowData)

    return NextResponse.json(
      {
        id: newEntryRef.key,
        ...flowData,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Erro ao registrar dados de fluxo:", error)
    return NextResponse.json({ error: "Falha ao registrar dados de fluxo" }, { status: 500 })
  }
}

// Função para verificar condições de alerta
async function checkAlertConditions(flowData: any) {
  try {
    // Obter configurações de alerta
    const configRef = ref(database, "alertConfig")
    const configSnapshot = await get(configRef)

    if (!configSnapshot.exists()) {
      return // Sem configurações de alerta
    }

    const config = configSnapshot.val()

    // Verificar se alertas estão habilitados
    if (!config.enabled) {
      return
    }

    // Obter tanques
    const tanksRef = ref(database, "tanks")
    const tanksSnapshot = await get(tanksRef)

    if (tanksSnapshot.exists()) {
      // Verificar níveis de tanque
      tanksSnapshot.forEach(async (tankSnapshot) => {
        const tank = tankSnapshot.val()
        const tankId = tankSnapshot.key

        if (tank.enabled && flowData.tankLevels && flowData.tankLevels[tankId]) {
          const level = flowData.tankLevels[tankId]

          // Alerta de nível baixo
          if (level <= tank.alertLow) {
            await createAlert({
              type: "low_level",
              subject: "Alerta: Nível Crítico na Caixa d'Água",
              message: `Níveis críticos nas seguintes caixas:\n- ${tank.name}: ${level.toFixed(1)}% (${((level / 100) * tank.capacity).toFixed(0)} de ${tank.capacity} litros)`,
              recipients: getAlertRecipients(config, "alertLowLevel"),
            })
          }
        }
      })
    }

    // Verificar vazamento
    if (flowData.leakDetected) {
      await createAlert({
        type: "leak",
        subject: "Alerta: Vazamento Detectado",
        message: `Possível vazamento detectado!\nFluxo contínuo de água por mais de 6 horas.\nVazão atual: ${flowData.flowRate.toFixed(2)} L/min\nPor favor, verifique suas instalações.`,
        recipients: getAlertRecipients(config, "alertLeak"),
      })
    }

    // Verificar consumo elevado
    if (config.highUsageThreshold && flowData.dailyUsage > config.highUsageThreshold) {
      await createAlert({
        type: "high_usage",
        subject: "Alerta: Consumo Elevado de Água",
        message: `Consumo diário acima do limite!\nConsumo atual: ${flowData.dailyUsage.toFixed(2)} litros\nLimite configurado: ${config.highUsageThreshold} litros\nVerifique possíveis desperdícios.`,
        recipients: getAlertRecipients(config, "alertHighUsage"),
      })
    }
  } catch (error) {
    console.error("Erro ao verificar condições de alerta:", error)
  }
}

// Função para criar um alerta
async function createAlert(alertData: any) {
  try {
    // Verificar se já existe um alerta similar recente (últimas 2 horas)
    const alertsRef = ref(database, "alerts")
    const alertsSnapshot = await get(alertsRef)

    if (alertsSnapshot.exists()) {
      const twoHoursAgo = new Date()
      twoHoursAgo.setHours(twoHoursAgo.getHours() - 2)

      let recentSimilarAlert = false
      alertsSnapshot.forEach((childSnapshot) => {
        const alert = childSnapshot.val()

        // Verificar se é do mesmo tipo e recente
        if (alert.type === alertData.type && new Date(alert.timestamp) > twoHoursAgo) {
          recentSimilarAlert = true
        }
      })

      if (recentSimilarAlert) {
        return // Evitar alertas duplicados
      }
    }

    // Criar novo alerta
    const newAlert = {
      ...alertData,
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      emailSent: false,
    }

    // Salvar no Firebase
    const alertsRefPush = ref(database, "alerts")
    const newAlertRef = push(alertsRefPush)
    await set(newAlertRef, newAlert)

    // Enviar email
    try {
      const response = await fetch("/api/alerts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          subject: newAlert.subject,
          message: newAlert.message,
          recipients: newAlert.recipients,
          alertType: newAlert.type,
        }),
      })

      if (response.ok) {
        // Atualizar status de envio
        await set(ref(database, `alerts/${newAlertRef.key}/emailSent`), true)
        await set(
          ref(database, `alerts/${newAlertRef.key}/sentTimestamp`),
          new Date().toISOString().replace("T", " ").substring(0, 19),
        )
      }
    } catch (error) {
      console.error("Erro ao enviar email de alerta:", error)
    }
  } catch (error) {
    console.error("Erro ao criar alerta:", error)
  }
}

// Função para obter destinatários de alerta
function getAlertRecipients(config: any, alertType: string) {
  if (!config.recipients || !Array.isArray(config.recipients)) {
    return []
  }

  return config.recipients
    .filter((recipient: any) => recipient.enabled && recipient[alertType])
    .map((recipient: any) => recipient.email)
}

