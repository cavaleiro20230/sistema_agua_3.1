import { NextResponse } from "next/server"
import { database, auth } from "@/lib/firebase"
import { ref, get, set, update, remove } from "firebase/database"
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth"

// GET /api/users - Obter todos os usuários
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (id) {
      // Obter um usuário específico
      const userRef = ref(database, `users/${id}`)
      const snapshot = await get(userRef)

      if (!snapshot.exists()) {
        return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
      }

      // Remover dados sensíveis
      const userData = snapshot.val()
      delete userData.password

      return NextResponse.json({
        id: snapshot.key,
        ...userData,
      })
    } else {
      // Obter todos os usuários
      const usersRef = ref(database, "users")
      const snapshot = await get(usersRef)

      if (!snapshot.exists()) {
        return NextResponse.json([])
      }

      const users: any[] = []
      snapshot.forEach((childSnapshot) => {
        const userData = childSnapshot.val()
        delete userData.password // Remover dados sensíveis

        users.push({
          id: childSnapshot.key,
          ...userData,
        })
      })

      return NextResponse.json(users)
    }
  } catch (error) {
    console.error("Erro ao obter usuários:", error)
    return NextResponse.json({ error: "Falha ao obter dados dos usuários" }, { status: 500 })
  }
}

// POST /api/users - Criar um novo usuário
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validar dados obrigatórios
    if (!data.email || !data.name || !data.password) {
      return NextResponse.json({ error: "Dados inválidos" }, { status: 400 })
    }

    // Verificar se o email já está em uso
    const usersRef = ref(database, "users")
    const snapshot = await get(usersRef)

    if (snapshot.exists()) {
      let emailExists = false
      snapshot.forEach((childSnapshot) => {
        const user = childSnapshot.val()
        if (user.email === data.email) {
          emailExists = true
        }
      })

      if (emailExists) {
        return NextResponse.json({ error: "Email já está em uso" }, { status: 400 })
      }
    }

    // Criar usuário no Firebase Authentication
    const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password)
    const user = userCredential.user

    // Atualizar perfil
    await updateProfile(user, {
      displayName: data.name,
    })

    // Preparar dados do usuário
    const userData = {
      name: data.name,
      email: data.email,
      role: data.role || "user",
      status: data.status || "pending",
      createdAt: new Date().toISOString(),
      receiveAlerts: data.receiveAlerts !== undefined ? data.receiveAlerts : false,
      uid: user.uid,
    }

    // Salvar no Firebase Realtime Database
    await set(ref(database, `users/${user.uid}`), userData)

    return NextResponse.json(
      {
        id: user.uid,
        ...userData,
      },
      { status: 201 },
    )
  } catch (error: any) {
    console.error("Erro ao criar usuário:", error)

    // Tratar erros específicos do Firebase Auth
    if (error.code === "auth/email-already-in-use") {
      return NextResponse.json({ error: "Email já está em uso" }, { status: 400 })
    } else if (error.code === "auth/invalid-email") {
      return NextResponse.json({ error: "Email inválido" }, { status: 400 })
    } else if (error.code === "auth/weak-password") {
      return NextResponse.json({ error: "Senha muito fraca" }, { status: 400 })
    }

    return NextResponse.json({ error: "Falha ao criar usuário" }, { status: 500 })
  }
}

// PUT /api/users/:id - Atualizar um usuário existente
export async function PUT(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "ID do usuário não fornecido" }, { status: 400 })
    }

    const data = await request.json()

    // Verificar se o usuário existe
    const userRef = ref(database, `users/${id}`)
    const snapshot = await get(userRef)

    if (!snapshot.exists()) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    // Preparar dados para atualização
    const updateData: any = {}

    if (data.name) updateData.name = data.name
    if (data.role) updateData.role = data.role
    if (data.status) updateData.status = data.status
    if (data.receiveAlerts !== undefined) updateData.receiveAlerts = data.receiveAlerts

    // Atualizar no Firebase
    await update(userRef, updateData)

    return NextResponse.json({
      id,
      ...snapshot.val(),
      ...updateData,
    })
  } catch (error) {
    console.error("Erro ao atualizar usuário:", error)
    return NextResponse.json({ error: "Falha ao atualizar usuário" }, { status: 500 })
  }
}

// DELETE /api/users/:id - Excluir um usuário
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "ID do usuário não fornecido" }, { status: 400 })
    }

    // Verificar se o usuário existe
    const userRef = ref(database, `users/${id}`)
    const snapshot = await get(userRef)

    if (!snapshot.exists()) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    const userData = snapshot.val()

    // Excluir do Firebase Authentication
    // Nota: Isso requer reautenticação em um ambiente real
    // Para simplificar, estamos apenas excluindo do Realtime Database

    // Excluir do Firebase Realtime Database
    await remove(userRef)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Erro ao excluir usuário:", error)
    return NextResponse.json({ error: "Falha ao excluir usuário" }, { status: 500 })
  }
}

