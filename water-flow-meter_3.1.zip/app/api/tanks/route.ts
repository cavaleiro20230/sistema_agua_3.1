import { NextResponse } from "next/server"
import { database } from "@/lib/firebase"
import { ref, get, set, update, remove } from "firebase/database"

// GET /api/tanks - Obter todos os tanques
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (id) {
      // Obter um tanque específico
      const tankRef = ref(database, `tanks/${id}`)
      const snapshot = await get(tankRef)

      if (!snapshot.exists()) {
        return NextResponse.json({ error: "Tanque não encontrado" }, { status: 404 })
      }

      return NextResponse.json({
        id: snapshot.key,
        ...snapshot.val(),
      })
    } else {
      // Obter todos os tanques
      const tanksRef = ref(database, "tanks")
      const snapshot = await get(tanksRef)

      if (!snapshot.exists()) {
        return NextResponse.json([])
      }

      const tanks: any[] = []
      snapshot.forEach((childSnapshot) => {
        tanks.push({
          id: childSnapshot.key,
          ...childSnapshot.val(),
        })
      })

      return NextResponse.json(tanks)
    }
  } catch (error) {
    console.error("Erro ao obter tanques:", error)
    return NextResponse.json({ error: "Falha ao obter dados dos tanques" }, { status: 500 })
  }
}

// POST /api/tanks - Criar um novo tanque
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validar dados obrigatórios
    if (!data.name || !data.capacity || data.capacity <= 0) {
      return NextResponse.json({ error: "Dados inválidos" }, { status: 400 })
    }

    // Preparar dados do tanque
    const tankData = {
      name: data.name,
      capacity: data.capacity,
      height: data.height || 100,
      level: data.level || 0,
      alertLow: data.alertLow || 20,
      alertMid: data.alertMid || 50,
      alertHigh: data.alertHigh || 90,
      enabled: data.enabled !== undefined ? data.enabled : true,
      createdAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
    }

    // Salvar no Firebase
    const tanksRef = ref(database, "tanks")
    const newTankRef = await set(ref(database, `tanks/${data.id || Date.now()}`), tankData)

    return NextResponse.json(
      {
        id: data.id || Date.now(),
        ...tankData,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Erro ao criar tanque:", error)
    return NextResponse.json({ error: "Falha ao criar tanque" }, { status: 500 })
  }
}

// PUT /api/tanks/:id - Atualizar um tanque existente
export async function PUT(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "ID do tanque não fornecido" }, { status: 400 })
    }

    const data = await request.json()

    // Verificar se o tanque existe
    const tankRef = ref(database, `tanks/${id}`)
    const snapshot = await get(tankRef)

    if (!snapshot.exists()) {
      return NextResponse.json({ error: "Tanque não encontrado" }, { status: 404 })
    }

    // Preparar dados para atualização
    const updateData = {
      ...data,
      lastUpdated: new Date().toISOString(),
    }

    // Atualizar no Firebase
    await update(tankRef, updateData)

    return NextResponse.json({
      id,
      ...snapshot.val(),
      ...updateData,
    })
  } catch (error) {
    console.error("Erro ao atualizar tanque:", error)
    return NextResponse.json({ error: "Falha ao atualizar tanque" }, { status: 500 })
  }
}

// DELETE /api/tanks/:id - Excluir um tanque
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "ID do tanque não fornecido" }, { status: 400 })
    }

    // Verificar se o tanque existe
    const tankRef = ref(database, `tanks/${id}`)
    const snapshot = await get(tankRef)

    if (!snapshot.exists()) {
      return NextResponse.json({ error: "Tanque não encontrado" }, { status: 404 })
    }

    // Excluir do Firebase
    await remove(tankRef)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Erro ao excluir tanque:", error)
    return NextResponse.json({ error: "Falha ao excluir tanque" }, { status: 500 })
  }
}

