"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { ArrowLeft, Settings, RefreshCw, Droplet, BarChart3, LineChart, Download } from "lucide-react"

// Tipos de dados
interface Tank {
  id: string
  name: string
  capacity: number
  level: number
  alertLow: number
  alertMid: number
  alertHigh: number
  height: number
  enabled: boolean
  lastUpdated: string
}

// Dados de exemplo
const mockTank: Tank = {
  id: "1",
  name: "Caixa Principal",
  capacity: 1000,
  level: 65.2,
  alertLow: 20,
  alertMid: 50,
  alertHigh: 90,
  height: 100,
  enabled: true,
  lastUpdated: "2024-03-06 14:30:22",
}

// Dados históricos de exemplo
const mockHistoryData = [
  { date: "01/03", level: 80 },
  { date: "02/03", level: 75 },
  { date: "03/03", level: 70 },
  { date: "04/03", level: 68 },
  { date: "05/03", level: 72 },
  { date: "06/03", level: 65 },
]

export default function TankDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [tank, setTank] = useState<Tank | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [chartType, setChartType] = useState<"bar" | "line">("bar")

  // Carregar dados do tanque
  useEffect(() => {
    // Em um ambiente real, isso seria uma chamada API
    setTank(mockTank)
    setIsLoading(false)
  }, [params.id])

  // Determina o status do tanque
  const getTankStatus = () => {
    if (!tank) return { status: "", color: "" }

    if (tank.level <= tank.alertLow) return { status: "Baixo", color: "destructive" }
    if (tank.level <= tank.alertMid) return { status: "Médio-Baixo", color: "warning" }
    if (tank.level <= tank.alertHigh) return { status: "Médio-Alto", color: "default" }
    return { status: "Cheio", color: "success" }
  }

  // Calcula o volume atual
  const getCurrentVolume = () => {
    if (!tank) return 0
    return ((tank.level / 100) * tank.capacity).toFixed(0)
  }

  // Atualizar dados do tanque
  const refreshTankData = () => {
    setIsLoading(true)

    // Em um ambiente real, isso seria uma chamada API
    setTimeout(() => {
      setTank({
        ...tank!,
        level: Math.min(Math.max(tank!.level + (Math.random() * 10 - 5), 0), 100),
        lastUpdated: new Date().toISOString().replace("T", " ").substring(0, 19),
      })
      setIsLoading(false)

      toast({
        title: "Dados atualizados",
        description: "Os dados do tanque foram atualizados com sucesso.",
      })
    }, 1000)
  }

  // Exportar dados históricos
  const exportData = () => {
    toast({
      title: "Exportação iniciada",
      description: "Os dados estão sendo exportados para CSV.",
    })
  }

  if (isLoading) {
    return (
      <div className="container mx-auto p-4 max-w-6xl flex items-center justify-center min-h-[50vh]">
        <div className="text-center">
          <Droplet className="h-12 w-12 text-blue-500 animate-pulse mx-auto mb-4" />
          <p className="text-lg">Carregando dados do tanque...</p>
        </div>
      </div>
    )
  }

  if (!tank) {
    return (
      <div className="container mx-auto p-4 max-w-6xl">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">Tanque não encontrado</h2>
          <p className="mb-4">O tanque solicitado não foi encontrado ou não está disponível.</p>
          <Button onClick={() => router.push("/")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar para o Dashboard
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => router.push("/")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold">{tank.name}</h1>
          <Badge variant={tank.enabled ? "success" : "destructive"}>{tank.enabled ? "Ativo" : "Inativo"}</Badge>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={refreshTankData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
          <Button variant="outline" onClick={() => router.push(`/tanks/${tank.id}/settings`)}>
            <Settings className="h-4 w-4 mr-2" />
            Configurações
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Visualização do Tanque */}
        <Card>
          <CardHeader>
            <CardTitle>Nível Atual</CardTitle>
            <CardDescription>Última atualização: {tank.lastUpdated}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              {/* Representação visual do tanque */}
              <div className="w-40 h-60 border-2 border-gray-300 rounded-md relative mb-4">
                <div
                  className={`absolute bottom-0 left-0 right-0 transition-all duration-1000 rounded-b-sm
                    ${
                      tank.level <= tank.alertLow
                        ? "bg-red-500"
                        : tank.level <= tank.alertMid
                          ? "bg-yellow-500"
                          : tank.level <= tank.alertHigh
                            ? "bg-blue-500"
                            : "bg-green-500"
                    }`}
                  style={{ height: `${tank.level}%` }}
                />

                {/* Marcações de nível */}
                <div className="absolute top-0 left-0 right-0 h-full">
                  <div className="absolute top-[10%] w-full border-t border-gray-400 border-dashed">
                    <span className="absolute -right-8 -top-2 text-xs">{tank.alertHigh}%</span>
                  </div>
                  <div className="absolute top-[50%] w-full border-t border-gray-400 border-dashed">
                    <span className="absolute -right-8 -top-2 text-xs">{tank.alertMid}%</span>
                  </div>
                  <div className="absolute top-[80%] w-full border-t border-gray-400 border-dashed">
                    <span className="absolute -right-8 -top-2 text-xs">{tank.alertLow}%</span>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <div className="text-3xl font-bold">{tank.level.toFixed(1)}%</div>
                <div className="text-lg">
                  {getCurrentVolume()} / {tank.capacity} L
                </div>
                <Badge className="mt-2" variant={getTankStatus().color as any}>
                  {getTankStatus().status}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Estatísticas */}
        <Card>
          <CardHeader>
            <CardTitle>Estatísticas</CardTitle>
            <CardDescription>Informações detalhadas sobre o tanque</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Capacidade Total:</span>
                <span className="font-medium">{tank.capacity} L</span>
              </div>
              <div className="flex justify-between">
                <span>Volume Atual:</span>
                <span className="font-medium">{getCurrentVolume()} L</span>
              </div>
              <div className="flex justify-between">
                <span>Espaço Disponível:</span>
                <span className="font-medium">{(tank.capacity - Number(getCurrentVolume())).toFixed(0)} L</span>
              </div>
              <div className="flex justify-between">
                <span>Altura do Tanque:</span>
                <span className="font-medium">{tank.height} cm</span>
              </div>
              <div className="flex justify-between">
                <span>Status:</span>
                <Badge variant={getTankStatus().color as any}>{getTankStatus().status}</Badge>
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <h4 className="font-medium">Níveis de Alerta</h4>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Nível Baixo: {tank.alertLow}%</span>
                  </div>
                  <Progress value={tank.alertLow} className="h-2 bg-gray-200" />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Nível Médio: {tank.alertMid}%</span>
                  </div>
                  <Progress value={tank.alertMid} className="h-2 bg-gray-200" />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Nível Alto: {tank.alertHigh}%</span>
                  </div>
                  <Progress value={tank.alertHigh} className="h-2 bg-gray-200" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Histórico */}
      <Card className="mt-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Histórico de Nível</CardTitle>
            <CardDescription>Variação nos últimos 7 dias</CardDescription>
          </div>
          <div className="flex gap-2">
            <div className="flex gap-2">
              <Button
                variant={chartType === "bar" ? "default" : "outline"}
                size="sm"
                onClick={() => setChartType("bar")}
              >
                <BarChart3 className="h-4 w-4 mr-1" />
                Barras
              </Button>
              <Button
                variant={chartType === "line" ? "default" : "outline"}
                size="sm"
                onClick={() => setChartType("line")}
              >
                <LineChart className="h-4 w-4 mr-1" />
                Linha
              </Button>
            </div>
            <Button variant="outline" size="sm" onClick={exportData}>
              <Download className="h-4 w-4 mr-1" />
              Exportar
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            {chartType === "bar" ? (
              <div className="flex items-end justify-between h-full">
                {mockHistoryData.map((data, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div
                      className={`w-12 rounded-t ${
                        data.level <= tank.alertLow
                          ? "bg-red-500"
                          : data.level <= tank.alertMid
                            ? "bg-yellow-500"
                            : data.level <= tank.alertHigh
                              ? "bg-blue-500"
                              : "bg-green-500"
                      }`}
                      style={{ height: `${data.level * 2.5}px` }}
                    />
                    <div className="text-xs mt-2">{data.date}</div>
                    <div className="text-xs font-medium">{data.level}%</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col justify-between h-full">
                <div className="relative h-[250px] w-full">
                  {/* Linhas de grade */}
                  <div className="absolute inset-0 flex flex-col justify-between">
                    {[0, 25, 50, 75, 100].map((level) => (
                      <div key={level} className="w-full border-t border-gray-200 relative">
                        <span className="absolute -left-8 -top-2 text-xs">{level}%</span>
                      </div>
                    ))}
                  </div>

                  {/* Linha do gráfico */}
                  <svg className="absolute inset-0 h-full w-full" viewBox="0 0 600 250" preserveAspectRatio="none">
                    <polyline
                      points={mockHistoryData.map((data, i) => `${i * 100},${250 - data.level * 2.5}`).join(" ")}
                      fill="none"
                      stroke="rgb(59, 130, 246)"
                      strokeWidth="3"
                    />
                  </svg>
                </div>
                <div className="flex justify-between mt-2">
                  {mockHistoryData.map((data, index) => (
                    <div key={index} className="text-xs text-center">
                      <div>{data.date}</div>
                      <div className="font-medium">{data.level}%</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

