"use client"

import { Label } from "@/components/ui/label"

import { Input } from "@/components/ui/input"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { TankCard } from "@/components/dashboard/tank-card"
import { FlowChart } from "@/components/dashboard/flow-chart"
import { WaterUsageSummary } from "@/components/dashboard/water-usage-summary"
import { SystemStatus } from "@/components/dashboard/system-status"
import { AlertSettings } from "@/components/dashboard/alert-settings"
import {
  AlertTriangle,
  Target,
  AlertCircle,
  Droplets,
  ContainerIcon as Tank,
  Save,
  RefreshCw,
  Download,
  Plus,
  Settings,
} from "lucide-react"
import { database } from "@/lib/firebase"
import { ref, onValue } from "firebase/database"

// Tipos de dados
interface TankData {
  id: string
  name: string
  capacity: number
  level: number
  alertLow: number
  alertMid: number
  alertHigh: number
  enabled: boolean
  lastUpdated?: string
}

export default function WaterMeterSystem() {
  // Estados para dados do sistema
  const [currentFlow, setCurrentFlow] = useState(2.5)
  const [totalVolume, setTotalVolume] = useState(1250.45)
  const [dailyUsage, setDailyUsage] = useState(125.5)
  const [monthlyUsage, setMonthlyUsage] = useState(3750.8)
  const [monthlyTarget, setMonthlyTarget] = useState(4000)
  const [leakDetected, setLeakDetected] = useState(false)
  const [costPerLiter, setCostPerLiter] = useState(0.003) // R$ 3,00 por m³

  // Estados para caixas d'água
  const [tanks, setTanks] = useState<TankData[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Carregar dados do Firebase
  useEffect(() => {
    // Carregar dados atuais
    const currentDataRef = ref(database, "currentData")
    const unsubscribe1 = onValue(currentDataRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        setCurrentFlow(data.flowRate || 0)
        setTotalVolume(data.totalVolume || 0)
        setLeakDetected(data.leakDetected || false)
      } else {
        // Dados de exemplo para demonstração
        setCurrentFlow(2.5)
        setTotalVolume(1250.45)
        setLeakDetected(Math.random() > 0.7)
      }
    })

    // Carregar dados de uso
    const usageRef = ref(database, "usageSummary")
    const unsubscribe2 = onValue(usageRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        setDailyUsage(data.daily || 0)
        setMonthlyUsage(data.monthly || 0)
        setMonthlyTarget(data.target || 4000)
      } else {
        // Dados de exemplo para demonstração
        setDailyUsage(125.5)
        setMonthlyUsage(3750.8)
      }
    })

    // Carregar tanques
    const tanksRef = ref(database, "tanks")
    const unsubscribe3 = onValue(tanksRef, (snapshot) => {
      if (snapshot.exists()) {
        const tanksData: TankData[] = []
        snapshot.forEach((childSnapshot) => {
          tanksData.push({
            id: childSnapshot.key || "",
            ...childSnapshot.val(),
          })
        })
        setTanks(tanksData)
      } else {
        // Dados de exemplo para demonstração
        setTanks([
          {
            id: "1",
            name: "Caixa Principal",
            capacity: 1000,
            level: 65,
            alertLow: 20,
            alertMid: 50,
            alertHigh: 90,
            enabled: true,
            lastUpdated: new Date().toISOString(),
          },
          {
            id: "2",
            name: "Caixa Secundária",
            capacity: 500,
            level: 45,
            alertLow: 20,
            alertMid: 50,
            alertHigh: 90,
            enabled: true,
            lastUpdated: new Date().toISOString(),
          },
        ])
      }
      setIsLoading(false)
    })

    // Carregar configurações
    const configRef = ref(database, "config")
    const unsubscribe4 = onValue(configRef, (snapshot) => {
      if (snapshot.exists() && snapshot.val().costPerLiter) {
        setCostPerLiter(snapshot.val().costPerLiter)
      }
    })

    return () => {
      unsubscribe1()
      unsubscribe2()
      unsubscribe3()
      unsubscribe4()
    }
  }, [])

  // Cálculo de custos
  const calculateCost = (volume: number) => {
    return (volume * costPerLiter).toFixed(2)
  }

  // Exportar dados para CSV
  const exportData = () => {
    toast({
      title: "Exportação iniciada",
      description: "Os dados estão sendo exportados para CSV.",
    })
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <h1 className="text-3xl font-bold mb-6">Sistema de Monitoramento de Água</h1>

      <Tabs defaultValue="dashboard" className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-7 gap-2">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="tank">Caixas d'Água</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
          <TabsTrigger value="analysis">Análise</TabsTrigger>
          <TabsTrigger value="alerts">Alertas</TabsTrigger>
          <TabsTrigger value="email">Config. Email</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>

        {/* Dashboard Principal */}
        <TabsContent value="dashboard" className="space-y-4">
          {/* Medições Principais */}
          <WaterUsageSummary />

          {/* Caixas d'Água - Resumo */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {isLoading ? (
              <Card>
                <CardContent className="p-6 flex justify-center items-center">
                  <RefreshCw className="h-8 w-8 animate-spin text-primary" />
                </CardContent>
              </Card>
            ) : tanks.length > 0 ? (
              tanks.map((tank) => <TankCard key={tank.id} {...tank} />)
            ) : (
              <Card>
                <CardContent className="p-6">
                  <p className="text-center text-muted-foreground">Nenhuma caixa d'água configurada</p>
                  <Button className="w-full mt-4">
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Caixa d'Água
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Gráfico de Fluxo */}
          <FlowChart
            title="Vazão de Água"
            description="Monitoramento em tempo real"
            period="day"
            dataKey="flowRate"
            height={250}
          />

          {/* Status do Sistema */}
          <SystemStatus />

          {/* Alertas */}
          <div className="space-y-2">
            {leakDetected && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Vazamento Detectado!</AlertTitle>
                <AlertDescription>
                  Fluxo contínuo detectado nas últimas 6 horas. Verifique suas instalações.
                </AlertDescription>
              </Alert>
            )}

            {tanks.some((tank) => tank.level <= tank.alertLow) && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Nível Crítico na Caixa d'Água!</AlertTitle>
                <AlertDescription>
                  Uma ou mais caixas estão com nível crítico. Verifique o abastecimento.
                </AlertDescription>
              </Alert>
            )}

            {tanks.some((tank) => tank.level >= tank.alertHigh) && (
              <Alert>
                <Droplets className="h-4 w-4" />
                <AlertTitle>Caixa d'Água Quase Cheia</AlertTitle>
                <AlertDescription>Uma ou mais caixas estão quase cheias.</AlertDescription>
              </Alert>
            )}
          </div>
        </TabsContent>

        {/* Caixas d'Água */}
        <TabsContent value="tank" className="space-y-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Caixas d'Água</h2>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Caixa
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <RefreshCw className="h-12 w-12 animate-spin text-primary" />
            </div>
          ) : tanks.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2">
              {tanks.map((tank) => (
                <Card key={tank.id}>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle>{tank.name}</CardTitle>
                      <Badge variant={tank.enabled ? "success" : "destructive"}>
                        {tank.enabled ? "Ativo" : "Inativo"}
                      </Badge>
                    </div>
                    <CardDescription>Capacidade: {tank.capacity} litros</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col items-center">
                      {/* Representação visual da caixa */}
                      <div className="w-40 h-60 border-2 border-gray-300 rounded-md relative mb-4">
                        <div
                          className={`absolute bottom-0 left-0 right-0 transition-all duration-1000 rounded-b-sm
                            ${
                              tank.level <= tank.alertLow
                                ? "bg-red-500"
                                : tank.level <= tank.alertMid
                                  ? "bg-yellow-500"
                                  : tank.level <= tank.alertHigh
                                    ? "bg-blue-500"
                                    : "bg-green-500"
                            }`}
                          style={{ height: `${tank.level}%` }}
                        />

                        {/* Marcações de nível */}
                        <div className="absolute top-0 left-0 right-0 h-full">
                          <div className="absolute top-[10%] w-full border-t border-gray-400 border-dashed">
                            <span className="absolute -right-8 -top-2 text-xs">{tank.alertHigh}%</span>
                          </div>
                          <div className="absolute top-[50%] w-full border-t border-gray-400 border-dashed">
                            <span className="absolute -right-8 -top-2 text-xs">{tank.alertMid}%</span>
                          </div>
                          <div className="absolute top-[80%] w-full border-t border-gray-400 border-dashed">
                            <span className="absolute -right-8 -top-2 text-xs">{tank.alertLow}%</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-center">
                        <div className="text-3xl font-bold">{tank.level.toFixed(1)}%</div>
                        <div className="text-lg">
                          {((tank.level / 100) * tank.capacity).toFixed(0)} / {tank.capacity} L
                        </div>
                        <Badge
                          className="mt-2"
                          variant={
                            tank.level <= tank.alertLow
                              ? "destructive"
                              : tank.level <= tank.alertMid
                                ? "warning"
                                : tank.level <= tank.alertHigh
                                  ? "default"
                                  : "success"
                          }
                        >
                          {tank.level <= tank.alertLow
                            ? "Baixo"
                            : tank.level <= tank.alertMid
                              ? "Médio-Baixo"
                              : tank.level <= tank.alertHigh
                                ? "Médio-Alto"
                                : "Cheio"}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex justify-between mt-6">
                      <Button variant="outline" onClick={() => (window.location.href = `/tanks/${tank.id}`)}>
                        Detalhes
                      </Button>
                      <Button variant="outline" onClick={() => (window.location.href = `/tanks/${tank.id}/settings`)}>
                        <Settings className="h-4 w-4 mr-2" />
                        Configurações
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Tank className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-medium mb-2">Nenhuma caixa d'água configurada</h3>
                <p className="text-muted-foreground mb-6">
                  Adicione sua primeira caixa d'água para começar a monitorar os níveis.
                </p>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Caixa d'Água
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Histórico */}
        <TabsContent value="history" className="space-y-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Histórico de Consumo</h2>
            <Button variant="outline" onClick={exportData}>
              <Download className="h-4 w-4 mr-2" />
              Exportar Dados
            </Button>
          </div>

          <FlowChart
            title="Histórico de Vazão"
            description="Vazão de água ao longo do tempo"
            period="week"
            dataKey="flowRate"
            height={300}
          />

          <FlowChart
            title="Consumo Diário"
            description="Consumo de água por dia"
            period="month"
            dataKey="totalVolume"
            height={300}
          />
        </TabsContent>

        {/* Análise */}
        <TabsContent value="analysis" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Análise de Consumo</CardTitle>
                <CardDescription>Comparação com média histórica</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Consumo Atual</span>
                    <Badge variant={dailyUsage > 120 ? "destructive" : "default"}>{dailyUsage.toFixed(2)} L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Média Diária</span>
                    <Badge>120 L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Variação</span>
                    <Badge variant={dailyUsage > 120 ? "destructive" : "default"}>
                      {(((dailyUsage - 120) / 120) * 100).toFixed(1)}%
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Previsão de Consumo</CardTitle>
                <CardDescription>Baseado no histórico</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Previsão Mensal</span>
                    <Badge>{(dailyUsage * 30).toFixed(0)} L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Custo Estimado</span>
                    <Badge variant="outline">R$ {calculateCost(dailyUsage * 30)}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Eficiência de Consumo</CardTitle>
              <CardDescription>Comparação com metas estabelecidas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Meta Mensal: {monthlyTarget} L</span>
                    <span>{((monthlyUsage / monthlyTarget) * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={(monthlyUsage / monthlyTarget) * 100} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span>Consumo por Pessoa: 125 L/dia</span>
                    <Badge variant={125 > 110 ? "destructive" : "success"}>
                      {125 > 110 ? "Acima da média" : "Abaixo da média"}
                    </Badge>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span>Economia Estimada</span>
                    <span>
                      R${" "}
                      {((monthlyTarget - monthlyUsage) * costPerLiter > 0
                        ? (monthlyTarget - monthlyUsage) * costPerLiter
                        : 0
                      ).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Alertas */}
        <TabsContent value="alerts" className="space-y-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Configuração de Alertas</h2>
            <Button variant="outline" onClick={() => (window.location.href = "/admin/alerts-history")}>
              Ver Histórico de Alertas
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Configuração de Alertas</CardTitle>
              <CardDescription>Defina limites para notificações</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Alerta de Consumo Diário</span>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={monthlyTarget / 30}
                    onChange={(e) => setMonthlyTarget(Number(e.target.value) * 30)}
                    className="w-20"
                  />
                  <span>L</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span>Alerta de Vazamento</span>
                <Badge>6 horas de fluxo contínuo</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Alerta de Meta Mensal</span>
                <Badge>90% da meta</Badge>
              </div>

              <Separator className="my-4" />

              <h4 className="font-medium mb-2">Alertas das Caixas d'Água</h4>

              {isLoading ? (
                <div className="flex justify-center py-4">
                  <RefreshCw className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : tanks.length > 0 ? (
                <div className="space-y-4">
                  {tanks.map((tank) => (
                    <div key={tank.id} className="border rounded-md p-4">
                      <h5 className="font-medium mb-2">{tank.name}</h5>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span>Nível Baixo</span>
                          <Badge variant="destructive">{tank.alertLow}%</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>Nível Médio</span>
                          <Badge variant="warning">{tank.alertMid}%</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>Nível Alto</span>
                          <Badge variant="success">{tank.alertHigh}%</Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">Nenhuma caixa d'água configurada</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Histórico de Alertas Recentes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leakDetected && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Vazamento Detectado</AlertTitle>
                    <AlertDescription>Fluxo contínuo detectado - Agora</AlertDescription>
                  </Alert>
                )}

                {tanks.some((tank) => tank.level <= tank.alertLow) && (
                  <Alert variant="destructive">
                    <Tank className="h-4 w-4" />
                    <AlertTitle>Nível Crítico na Caixa d'Água</AlertTitle>
                    <AlertDescription>
                      {tanks
                        .filter((tank) => tank.level <= tank.alertLow)
                        .map((tank) => (
                          <div key={tank.id}>
                            {tank.name}: {tank.level.toFixed(1)}% - Agora
                          </div>
                        ))}
                    </AlertDescription>
                  </Alert>
                )}

                <Alert>
                  <Tank className="h-4 w-4" />
                  <AlertTitle>Nível Médio na Caixa d'Água</AlertTitle>
                  <AlertDescription>50% de capacidade atingida - 28/02/2024 10:15</AlertDescription>
                </Alert>

                <Alert>
                  <Target className="h-4 w-4" />
                  <AlertTitle>Meta Mensal Próxima</AlertTitle>
                  <AlertDescription>90% da meta mensal atingida - 27/02/2024 18:45</AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configuração de Email */}
        <TabsContent value="email" className="space-y-4">
          <AlertSettings />
        </TabsContent>

        {/* Configurações */}
        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Sistema</CardTitle>
              <CardDescription>Ajuste os parâmetros do medidor</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="calibration-factor">Fator de Calibração</Label>
                  <div className="flex items-center gap-2">
                    <Input type="number" id="calibration-factor" value="7.5" step="0.1" min="0.1" />
                    <span>pulsos/L</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Fator de calibração do sensor de fluxo (YF-S201 = 7.5 pulsos por litro)
                  </p>
                </div>

                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="cost-per-liter">Custo por m³</Label>
                  <div className="flex items-center gap-2">
                    <span>R$</span>
                    <Input
                      type="number"
                      id="cost-per-liter"
                      value={(costPerLiter * 1000).toFixed(2)}
                      step="0.01"
                      min="0"
                      onChange={(e) => setCostPerLiter(Number(e.target.value) / 1000)}
                    />
                  </div>
                </div>

                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="monthly-target">Meta Mensal</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      id="monthly-target"
                      value={monthlyTarget}
                      step="100"
                      min="0"
                      onChange={(e) => setMonthlyTarget(Number(e.target.value))}
                    />
                    <span>L</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <Button variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Restaurar Padrões
                </Button>
                <Button>
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Configurações
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

