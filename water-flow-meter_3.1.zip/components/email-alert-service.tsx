"use client"

import { useEffect, useState } from "react"
import { database } from "@/lib/firebase"
import { ref, onValue, set } from "firebase/database"
import { toast } from "@/hooks/use-toast"

interface AlertConfig {
  enabled: boolean
  recipients: Recipient[]
  highUsageThreshold: number
}

interface Recipient {
  email: string
  enabled: boolean
  alertLowLevel: boolean
  alertLeak: boolean
  alertHighUsage: boolean
}

interface WaterSystemData {
  flowRate: number
  tankLevel: number
  dailyUsage: number
  leakDetected: boolean
}

export function EmailAlertService() {
  const [alertConfig, setAlertConfig] = useState<AlertConfig | null>(null)
  const [systemData, setSystemData] = useState<WaterSystemData | null>(null)
  const [alertsSent, setAlertsSent] = useState({
    lowLevel: false,
    leak: false,
    highUsage: false,
  })

  // Load alert configuration from Firebase
  useEffect(() => {
    const configRef = ref(database, "emailConfig")
    const unsubscribe = onValue(configRef, (snapshot) => {
      if (snapshot.exists()) {
        setAlertConfig(snapshot.val())
      }
    })

    return () => unsubscribe()
  }, [])

  // Monitor system data for alert conditions
  useEffect(() => {
    const systemRef = ref(database, "waterSystem")
    const unsubscribe = onValue(systemRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        setSystemData({
          flowRate: data.flowRate || 0,
          tankLevel: data.tanks?.[0]?.level || 0,
          dailyUsage: data.dailyUsage || 0,
          leakDetected: data.leakDetected || false,
        })
      }
    })

    return () => unsubscribe()
  }, [])

  // Check for alert conditions and send alerts
  useEffect(() => {
    if (!alertConfig?.enabled || !systemData) return

    const checkAndSendAlert = async (
      condition: boolean,
      alertType: "lowLevel" | "leak" | "highUsage",
      subject: string,
      message: string,
    ) => {
      if (condition && !alertsSent[alertType]) {
        // Get recipients who have this alert type enabled
        const recipients = alertConfig.recipients
          .filter((r) => r.enabled && r[`alert${alertType.charAt(0).toUpperCase() + alertType.slice(1)}`])
          .map((r) => r.email)

        if (recipients.length > 0) {
          try {
            const response = await fetch("/api/alerts", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                subject,
                message,
                recipients,
                alertType,
              }),
            })

            if (response.ok) {
              setAlertsSent((prev) => ({ ...prev, [alertType]: true }))

              // Log to Firebase
              const alertsRef = ref(database, `alerts/${Date.now()}`)
              set(alertsRef, {
                subject,
                message,
                timestamp: new Date().toISOString(),
                recipients,
                type: alertType,
                processed: true,
                emailSent: true,
              })

              toast({
                title: "Alerta enviado",
                description: `Alerta de ${alertType} enviado para ${recipients.length} destinatário(s)`,
              })
            }
          } catch (error) {
            console.error("Failed to send alert:", error)
          }
        }
      } else if (!condition) {
        // Reset alert sent flag when condition is no longer true
        if (alertsSent[alertType]) {
          setAlertsSent((prev) => ({ ...prev, [alertType]: false }))
        }
      }
    }

    // Check for low tank level
    const tankAlertLow = 20 // This would come from your settings
    checkAndSendAlert(
      systemData.tankLevel <= tankAlertLow,
      "lowLevel",
      "Alerta: Nível Crítico na Caixa d'Água",
      `A caixa d'água está com apenas ${systemData.tankLevel.toFixed(1)}% da capacidade.\nVerifique o abastecimento o mais rápido possível.`,
    )

    // Check for leak
    checkAndSendAlert(
      systemData.leakDetected,
      "leak",
      "Alerta: Vazamento Detectado",
      `Possível vazamento detectado!\nFluxo contínuo de água por mais de 6 horas.\nVazão atual: ${systemData.flowRate.toFixed(2)} L/min\nPor favor, verifique suas instalações.`,
    )

    // Check for high usage
    checkAndSendAlert(
      systemData.dailyUsage > alertConfig.highUsageThreshold,
      "highUsage",
      "Alerta: Consumo Elevado de Água",
      `Consumo diário acima do limite!\nConsumo atual: ${systemData.dailyUsage.toFixed(2)} litros\nLimite configurado: ${alertConfig.highUsageThreshold} litros\nVerifique possíveis desperdícios.`,
    )
  }, [alertConfig, systemData, alertsSent])

  // This component doesn't render anything visible
  return null
}

