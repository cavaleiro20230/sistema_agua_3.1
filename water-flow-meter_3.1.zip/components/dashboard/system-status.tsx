"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Wifi, WifiOff, Database, ServerOff, CheckCircle, AlertTriangle, AlertCircle } from "lucide-react"
import { database } from "@/lib/firebase"
import { ref, onValue } from "firebase/database"

export function SystemStatus() {
  const [deviceStatus, setDeviceStatus] = useState<"online" | "offline" | "unknown">("unknown")
  const [databaseStatus, setDatabaseStatus] = useState<"connected" | "disconnected" | "unknown">("unknown")
  const [lastUpdate, setLastUpdate] = useState<string | null>(null)
  const [alerts, setAlerts] = useState<{
    leakDetected: boolean
    lowBattery: boolean
    sensorError: boolean
  }>({
    leakDetected: false,
    lowBattery: false,
    sensorError: false,
  })

  // Carregar status do sistema
  useEffect(() => {
    const statusRef = ref(database, "systemStatus")
    const unsubscribe = onValue(statusRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        setDeviceStatus(data.deviceOnline ? "online" : "offline")
        setDatabaseStatus(data.databaseConnected ? "connected" : "disconnected")
        setLastUpdate(data.lastUpdate || null)

        setAlerts({
          leakDetected: data.leakDetected || false,
          lowBattery: data.lowBattery || false,
          sensorError: data.sensorError || false,
        })
      } else {
        // Dados de exemplo para demonstração
        setDeviceStatus("online")
        setDatabaseStatus("connected")
        setLastUpdate(new Date().toISOString())

        // Simular alguns alertas para demonstração
        setAlerts({
          leakDetected: Math.random() > 0.7,
          lowBattery: Math.random() > 0.8,
          sensorError: false,
        })
      }
    })

    return () => unsubscribe()
  }, [])

  // Formatar data de última atualização
  const formatLastUpdate = () => {
    if (!lastUpdate) return "Nunca"

    try {
      const date = new Date(lastUpdate)
      return date.toLocaleString()
    } catch (error) {
      return lastUpdate
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Status do Sistema</CardTitle>
        <CardDescription>Monitoramento em tempo real</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            {deviceStatus === "online" ? (
              <Wifi className="h-5 w-5 text-green-500" />
            ) : (
              <WifiOff className="h-5 w-5 text-red-500" />
            )}
            <div>
              <p className="text-sm font-medium">Dispositivo</p>
              <Badge variant={deviceStatus === "online" ? "success" : "destructive"}>
                {deviceStatus === "online" ? "Online" : "Offline"}
              </Badge>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {databaseStatus === "connected" ? (
              <Database className="h-5 w-5 text-green-500" />
            ) : (
              <ServerOff className="h-5 w-5 text-red-500" />
            )}
            <div>
              <p className="text-sm font-medium">Banco de Dados</p>
              <Badge variant={databaseStatus === "connected" ? "success" : "destructive"}>
                {databaseStatus === "connected" ? "Conectado" : "Desconectado"}
              </Badge>
            </div>
          </div>
        </div>

        <div>
          <p className="text-sm font-medium">Última Atualização</p>
          <p className="text-sm">{formatLastUpdate()}</p>
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium">Alertas do Sistema</p>

          {!alerts.leakDetected && !alerts.lowBattery && !alerts.sensorError ? (
            <div className="flex items-center gap-2 text-green-500">
              <CheckCircle className="h-5 w-5" />
              <p className="text-sm">Sistema funcionando normalmente</p>
            </div>
          ) : (
            <div className="space-y-2">
              {alerts.leakDetected && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Vazamento Detectado</AlertTitle>
                  <AlertDescription>Fluxo contínuo detectado. Verifique suas instalações.</AlertDescription>
                </Alert>
              )}

              {alerts.lowBattery && (
                <Alert variant="warning">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Bateria Baixa</AlertTitle>
                  <AlertDescription>
                    A bateria do dispositivo está baixa. Recarregue ou substitua em breve.
                  </AlertDescription>
                </Alert>
              )}

              {alerts.sensorError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Erro no Sensor</AlertTitle>
                  <AlertDescription>Falha detectada no sensor de fluxo. Verifique a conexão.</AlertDescription>
                </Alert>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

