"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { DropletIcon, History, Calendar, BarChart3 } from "lucide-react"
import { database } from "@/lib/firebase"
import { ref, onValue } from "firebase/database"

interface WaterUsageSummaryProps {
  compact?: boolean
}

export function WaterUsageSummary({ compact = false }: WaterUsageSummaryProps) {
  const [currentFlow, setCurrentFlow] = useState(0)
  const [totalVolume, setTotalVolume] = useState(0)
  const [dailyUsage, setDailyUsage] = useState(0)
  const [monthlyUsage, setMonthlyUsage] = useState(0)
  const [monthlyTarget, setMonthlyTarget] = useState(4000)
  const [costPerLiter, setCostPerLiter] = useState(0.003) // R$ 3,00 por m³
  const [isLoading, setIsLoading] = useState(true)

  // Carregar dados do Firebase
  useEffect(() => {
    const currentDataRef = ref(database, "currentData")
    const unsubscribe1 = onValue(currentDataRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        setCurrentFlow(data.flowRate || 0)
        setTotalVolume(data.totalVolume || 0)
      }
      setIsLoading(false)
    })

    const usageRef = ref(database, "usageSummary")
    const unsubscribe2 = onValue(usageRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        setDailyUsage(data.daily || 0)
        setMonthlyUsage(data.monthly || 0)
        setMonthlyTarget(data.target || 4000)
      } else {
        // Dados de exemplo para demonstração
        setDailyUsage(125.5)
        setMonthlyUsage(3750.8)
      }
    })

    const configRef = ref(database, "config")
    const unsubscribe3 = onValue(configRef, (snapshot) => {
      if (snapshot.exists() && snapshot.val().costPerLiter) {
        setCostPerLiter(snapshot.val().costPerLiter)
      }
    })

    return () => {
      unsubscribe1()
      unsubscribe2()
      unsubscribe3()
    }
  }, [])

  // Cálculo de custos
  const calculateCost = (volume: number) => {
    return (volume * costPerLiter).toFixed(2)
  }

  if (compact) {
    return (
      <div className="grid gap-4 grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Consumo Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dailyUsage.toFixed(1)} L</div>
            <p className="text-xs text-muted-foreground">R$ {calculateCost(dailyUsage)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Vazão Atual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentFlow.toFixed(1)} L/min</div>
            <p className="text-xs text-muted-foreground">Total: {totalVolume.toFixed(0)} L</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Vazão Atual</CardTitle>
          <DropletIcon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{currentFlow.toFixed(1)} L/min</div>
          <p className="text-xs text-muted-foreground">Média: 2.8 L/min</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Volume Total</CardTitle>
          <History className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalVolume.toFixed(0)} L</div>
          <p className="text-xs text-muted-foreground">Desde a instalação</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Consumo Hoje</CardTitle>
          <Calendar className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{dailyUsage.toFixed(1)} L</div>
          <p className="text-xs text-muted-foreground">R$ {calculateCost(dailyUsage)}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Consumo Mensal</CardTitle>
          <BarChart3 className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{monthlyUsage.toFixed(0)} L</div>
          <div className="mt-2">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>Meta: {monthlyTarget} L</span>
              <span>{((monthlyUsage / monthlyTarget) * 100).toFixed(0)}%</span>
            </div>
            <Progress value={(monthlyUsage / monthlyTarget) * 100} className="h-1" />
          </div>
          <p className="text-xs text-muted-foreground mt-2">R$ {calculateCost(monthlyUsage)}</p>
        </CardContent>
      </Card>
    </div>
  )
}

