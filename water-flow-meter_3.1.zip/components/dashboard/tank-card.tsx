"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ContainerIcon as Tank, Settings, ArrowRight } from "lucide-react"
import { useRouter } from "next/navigation"

interface TankCardProps {
  id: string
  name: string
  capacity: number
  level: number
  alertLow: number
  alertMid: number
  alertHigh: number
  lastUpdated?: string
  compact?: boolean
}

export function TankCard({
  id,
  name,
  capacity,
  level,
  alertLow,
  alertMid,
  alertHigh,
  lastUpdated,
  compact = false,
}: TankCardProps) {
  const router = useRouter()
  const [animatedLevel, setAnimatedLevel] = useState(0)

  // Animação suave do nível
  useEffect(() => {
    const duration = 1000 // ms
    const interval = 20 // ms
    const steps = duration / interval
    const increment = (level - animatedLevel) / steps

    let currentStep = 0
    const timer = setInterval(() => {
      currentStep++
      setAnimatedLevel((prev) => {
        const next = prev + increment
        if (currentStep >= steps) {
          clearInterval(timer)
          return level
        }
        return next
      })
    }, interval)

    return () => clearInterval(timer)
  }, [level])

  // Determina o status do tanque
  const getTankStatus = () => {
    if (level <= alertLow) return { status: "Baixo", color: "destructive" }
    if (level <= alertMid) return { status: "Médio", color: "warning" }
    if (level <= alertHigh) return { status: "Bom", color: "default" }
    return { status: "Cheio", color: "success" }
  }

  // Calcula o volume atual
  const getCurrentVolume = () => {
    return ((level / 100) * capacity).toFixed(0)
  }

  // Navegar para a página de detalhes do tanque
  const goToTankDetails = () => {
    router.push(`/tanks/${id}`)
  }

  // Navegar para a página de configurações do tanque
  const goToTankSettings = (e: React.MouseEvent) => {
    e.stopPropagation()
    router.push(`/tanks/${id}/settings`)
  }

  if (compact) {
    return (
      <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={goToTankDetails}>
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium text-sm">{name}</h3>
            <Badge variant={getTankStatus().color as any}>{level.toFixed(1)}%</Badge>
          </div>
          <Progress value={animatedLevel} className="h-2 mb-1" />
          <div className="flex justify-between items-center text-xs text-muted-foreground">
            <span>{getCurrentVolume()} L</span>
            <span>{capacity} L</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={goToTankDetails}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{name}</CardTitle>
        <Tank className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-2xl font-bold">{level.toFixed(1)}%</span>
            <Badge variant={getTankStatus().color as any}>{getTankStatus().status}</Badge>
          </div>

          <Progress value={animatedLevel} className="h-3" />

          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{getCurrentVolume()} L</span>
            <span>{capacity} L</span>
          </div>

          {lastUpdated && (
            <div className="text-xs text-muted-foreground mt-2">
              Atualizado: {new Date(lastUpdated).toLocaleString()}
            </div>
          )}

          <div className="flex justify-between items-center mt-4">
            <Button variant="outline" size="sm" onClick={goToTankSettings}>
              <Settings className="h-3 w-3 mr-1" />
              Configurar
            </Button>
            <Button variant="ghost" size="sm" onClick={goToTankDetails}>
              Detalhes
              <ArrowRight className="h-3 w-3 ml-1" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

