"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/hooks/use-toast"
import { Save, Trash2, Plus, Mail } from "lucide-react"
import { database } from "@/lib/firebase"
import { ref, onValue, set } from "firebase/database"

interface Recipient {
  email: string
  enabled: boolean
  alertLowLevel: boolean
  alertLeak: boolean
  alertHighUsage: boolean
}

interface AlertConfig {
  enabled: boolean
  recipients: Recipient[]
  highUsageThreshold: number
  emailFrequency: "immediate" | "daily" | "weekly"
}

export function AlertSettings() {
  const [config, setConfig] = useState<AlertConfig>({
    enabled: true,
    recipients: [{ email: "", enabled: true, alertLowLevel: true, alertLeak: true, alertHighUsage: true }],
    highUsageThreshold: 200,
    emailFrequency: "immediate",
  })
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)

  // Carregar configurações do Firebase
  useEffect(() => {
    const configRef = ref(database, "emailConfig")
    const unsubscribe = onValue(configRef, (snapshot) => {
      if (snapshot.exists()) {
        setConfig(snapshot.val())
      }
      setIsLoading(false)
    })

    return () => unsubscribe()
  }, [])

  // Adicionar destinatário
  const addRecipient = () => {
    if (config.recipients.length >= 5) {
      toast({
        title: "Limite atingido",
        description: "Você pode adicionar no máximo 5 destinatários.",
        variant: "destructive",
      })
      return
    }

    setConfig({
      ...config,
      recipients: [
        ...config.recipients,
        { email: "", enabled: true, alertLowLevel: true, alertLeak: true, alertHighUsage: true },
      ],
    })
  }

  // Remover destinatário
  const removeRecipient = (index: number) => {
    if (config.recipients.length <= 1) {
      toast({
        title: "Não é possível remover",
        description: "Você deve manter pelo menos um destinatário.",
        variant: "destructive",
      })
      return
    }

    setConfig({
      ...config,
      recipients: config.recipients.filter((_, i) => i !== index),
    })
  }

  // Atualizar destinatário
  const updateRecipient = (index: number, field: keyof Recipient, value: any) => {
    const newRecipients = [...config.recipients]
    newRecipients[index] = { ...newRecipients[index], [field]: value }

    setConfig({
      ...config,
      recipients: newRecipients,
    })
  }

  // Salvar configurações
  const saveConfig = async () => {
    // Validação de emails
    const validEmails = config.recipients
      .filter((r) => r.enabled)
      .every((r) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        return emailRegex.test(r.email)
      })

    if (!validEmails) {
      toast({
        title: "Erro de validação",
        description: "Por favor, verifique se todos os emails estão corretos.",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)

    try {
      // Salvar no Firebase
      await set(ref(database, "emailConfig"), config)

      toast({
        title: "Configurações salvas",
        description: "As configurações de alerta por email foram atualizadas com sucesso.",
      })
    } catch (error) {
      console.error("Erro ao salvar configurações:", error)
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar as configurações. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Testar envio de email
  const testEmail = async () => {
    // Validação de emails
    const validEmails = config.recipients
      .filter((r) => r.enabled)
      .every((r) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        return emailRegex.test(r.email)
      })

    if (!validEmails) {
      toast({
        title: "Erro de validação",
        description: "Por favor, verifique se todos os emails estão corretos.",
        variant: "destructive",
      })
      return
    }

    try {
      // Enviar email de teste
      const recipients = config.recipients.filter((r) => r.enabled).map((r) => r.email)

      if (recipients.length === 0) {
        toast({
          title: "Nenhum destinatário",
          description: "Não há destinatários ativos para enviar o email de teste.",
          variant: "destructive",
        })
        return
      }

      const response = await fetch("/api/alerts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          subject: "Teste de Alerta - Sistema de Monitoramento de Água",
          message:
            "Este é um email de teste do Sistema de Monitoramento de Água.\n\nSe você recebeu este email, significa que as configurações de alerta estão funcionando corretamente.",
          recipients,
          alertType: "test",
        }),
      })

      if (response.ok) {
        toast({
          title: "Email de teste enviado",
          description: "Um email de teste foi enviado para os destinatários configurados.",
        })
      } else {
        throw new Error("Falha ao enviar email de teste")
      }
    } catch (error) {
      console.error("Erro ao enviar email de teste:", error)
      toast({
        title: "Erro ao enviar",
        description: "Ocorreu um erro ao enviar o email de teste. Verifique as configurações.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Configuração de Alertas por Email</CardTitle>
          <CardDescription>Carregando configurações...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configuração de Alertas por Email</CardTitle>
        <CardDescription>Configure destinatários e tipos de alertas</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-2">
          <Switch
            id="email-alerts"
            checked={config.enabled}
            onCheckedChange={(checked) => setConfig({ ...config, enabled: checked })}
          />
          <Label htmlFor="email-alerts">Ativar alertas por email</Label>
        </div>

        <div className="pt-4">
          <h3 className="text-lg font-medium mb-2">Destinatários</h3>

          {config.recipients.map((recipient, index) => (
            <div key={index} className="border rounded-md p-4 mb-4">
              <div className="flex justify-between items-center mb-2">
                <h4 className="font-medium">Destinatário {index + 1}</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeRecipient(index)}
                  disabled={config.recipients.length === 1}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id={`recipient-enabled-${index}`}
                    checked={recipient.enabled}
                    onCheckedChange={(checked) => updateRecipient(index, "enabled", checked)}
                  />
                  <Label htmlFor={`recipient-enabled-${index}`}>Ativo</Label>
                </div>

                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor={`email-${index}`}>Email</Label>
                  <Input
                    type="email"
                    id={`email-${index}`}
                    placeholder="exemplo@email.com"
                    value={recipient.email}
                    onChange={(e) => updateRecipient(index, "email", e.target.value)}
                    disabled={!recipient.enabled}
                  />
                </div>

                <div className="space-y-2">
                  <h5 className="text-sm font-medium">Tipos de Alerta</h5>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id={`low-level-${index}`}
                      checked={recipient.alertLowLevel}
                      onCheckedChange={(checked) => updateRecipient(index, "alertLowLevel", checked)}
                      disabled={!recipient.enabled}
                    />
                    <Label htmlFor={`low-level-${index}`}>Nível baixo na caixa d'água</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      id={`leak-${index}`}
                      checked={recipient.alertLeak}
                      onCheckedChange={(checked) => updateRecipient(index, "alertLeak", checked)}
                      disabled={!recipient.enabled}
                    />
                    <Label htmlFor={`leak-${index}`}>Detecção de vazamento</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      id={`high-usage-${index}`}
                      checked={recipient.alertHighUsage}
                      onCheckedChange={(checked) => updateRecipient(index, "alertHighUsage", checked)}
                      disabled={!recipient.enabled}
                    />
                    <Label htmlFor={`high-usage-${index}`}>Consumo elevado</Label>
                  </div>
                </div>
              </div>
            </div>
          ))}

          <Button
            variant="outline"
            onClick={addRecipient}
            disabled={config.recipients.length >= 5 || !config.enabled}
            className="w-full"
          >
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Destinatário
          </Button>
        </div>

        <Separator className="my-4" />

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Configurações Adicionais</h3>

          <div className="grid w-full items-center gap-1.5">
            <Label htmlFor="usage-threshold">Limite de consumo diário (L)</Label>
            <Input
              type="number"
              id="usage-threshold"
              value={config.highUsageThreshold}
              onChange={(e) => setConfig({ ...config, highUsageThreshold: Number(e.target.value) })}
              disabled={!config.enabled}
            />
            <p className="text-sm text-muted-foreground">
              Um alerta será enviado quando o consumo diário ultrapassar este valor
            </p>
          </div>

          <div className="grid w-full items-center gap-1.5">
            <Label htmlFor="email-frequency">Frequência de relatórios</Label>
            <select
              id="email-frequency"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              value={config.emailFrequency}
              onChange={(e) => setConfig({ ...config, emailFrequency: e.target.value as any })}
              disabled={!config.enabled}
            >
              <option value="immediate">Imediato (apenas alertas)</option>
              <option value="daily">Relatório Diário</option>
              <option value="weekly">Relatório Semanal</option>
            </select>
            <p className="text-sm text-muted-foreground">Define a frequência de envio de relatórios de consumo</p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={testEmail} disabled={!config.enabled || isSaving}>
          <Mail className="h-4 w-4 mr-2" />
          Enviar Email de Teste
        </Button>
        <Button onClick={saveConfig} disabled={isSaving}>
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? "Salvando..." : "Salvar Configurações"}
        </Button>
      </CardFooter>
    </Card>
  )
}

