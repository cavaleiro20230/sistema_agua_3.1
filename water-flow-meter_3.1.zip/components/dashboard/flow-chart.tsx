"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { LineChart, BarChart, RefreshCw, Download } from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface FlowData {
  id: string
  timestamp: string
  flowRate: number
  totalVolume?: number
}

interface FlowChartProps {
  title: string
  description?: string
  period?: "day" | "week" | "month" | "year"
  dataKey?: "flowRate" | "totalVolume"
  height?: number
}

export function FlowChart({ title, description, period = "day", dataKey = "flowRate", height = 300 }: FlowChartProps) {
  const [data, setData] = useState<FlowData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [chartType, setChartType] = useState<"line" | "bar">("line")
  const [selectedPeriod, setSelectedPeriod] = useState(period)

  // Carregar dados
  useEffect(() => {
    fetchData()
  }, [selectedPeriod])

  // Função para buscar dados
  const fetchData = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/flow-data?period=${selectedPeriod}&limit=100`)
      if (response.ok) {
        const result = await response.json()
        setData(result)
      } else {
        // Dados de exemplo para demonstração
        const mockData: FlowData[] = []
        const now = new Date()

        for (let i = 0; i < 24; i++) {
          const timestamp = new Date(now)
          timestamp.setHours(now.getHours() - i)

          mockData.push({
            id: `mock-${i}`,
            timestamp: timestamp.toISOString(),
            flowRate: Math.random() * 5 + 1,
            totalVolume: 1000 + i * 10,
          })
        }

        setData(mockData)
      }
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
      toast({
        title: "Erro ao carregar dados",
        description: "Não foi possível obter os dados de fluxo.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Exportar dados
  const exportData = () => {
    // Preparar dados para CSV
    const headers = ["Data", "Hora", dataKey === "flowRate" ? "Vazão (L/min)" : "Volume Total (L)"]
    const csvData = data.map((item) => {
      const date = new Date(item.timestamp)
      return [
        date.toLocaleDateString(),
        date.toLocaleTimeString(),
        dataKey === "flowRate" ? item.flowRate.toFixed(2) : item.totalVolume?.toFixed(2),
      ]
    })

    // Converter para formato CSV
    const csvContent = [headers.join(","), ...csvData.map((row) => row.join(","))].join("\n")

    // Criar blob e link para download
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `dados_fluxo_${selectedPeriod}_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Exportação concluída",
      description: "Os dados foram exportados para CSV.",
    })
  }

  // Formatar dados para exibição
  const formatData = () => {
    // Ordenar por timestamp (mais antigo primeiro)
    const sortedData = [...data].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())

    // Formatar labels de acordo com o período
    const formattedData = sortedData.map((item) => {
      const date = new Date(item.timestamp)
      let label = ""

      switch (selectedPeriod) {
        case "day":
          label = date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
          break
        case "week":
          label = date.toLocaleDateString([], { weekday: "short", day: "numeric" })
          break
        case "month":
          label = date.toLocaleDateString([], { day: "numeric", month: "short" })
          break
        case "year":
          label = date.toLocaleDateString([], { month: "short" })
          break
      }

      return {
        label,
        value: dataKey === "flowRate" ? item.flowRate : item.totalVolume || 0,
      }
    })

    return formattedData
  }

  const chartData = formatData()

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle>{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </div>
        <div className="flex gap-2">
          <Select value={selectedPeriod} onValueChange={(value: any) => setSelectedPeriod(value)}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Hoje</SelectItem>
              <SelectItem value="week">Semana</SelectItem>
              <SelectItem value="month">Mês</SelectItem>
              <SelectItem value="year">Ano</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex gap-1">
            <Button
              variant={chartType === "line" ? "default" : "outline"}
              size="icon"
              onClick={() => setChartType("line")}
            >
              <LineChart className="h-4 w-4" />
            </Button>
            <Button
              variant={chartType === "bar" ? "default" : "outline"}
              size="icon"
              onClick={() => setChartType("bar")}
            >
              <BarChart className="h-4 w-4" />
            </Button>
          </div>

          <Button variant="outline" size="icon" onClick={fetchData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
          </Button>

          <Button variant="outline" size="icon" onClick={exportData} disabled={isLoading || data.length === 0}>
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center" style={{ height: `${height}px` }}>
            <RefreshCw className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : data.length === 0 ? (
          <div className="flex justify-center items-center" style={{ height: `${height}px` }}>
            <p className="text-muted-foreground">Nenhum dado disponível</p>
          </div>
        ) : (
          <div style={{ height: `${height}px` }}>
            {chartType === "line" ? (
              <div className="relative h-full w-full">
                {/* Linhas de grade */}
                <div className="absolute inset-0 flex flex-col justify-between">
                  {[0, 25, 50, 75, 100].map((level) => (
                    <div key={level} className="w-full border-t border-gray-100 relative">
                      <span className="absolute -left-8 -top-2 text-xs text-muted-foreground">
                        {dataKey === "flowRate" ? (level / 20).toFixed(1) : (level * 10).toString()}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Linha do gráfico */}
                <svg
                  className="absolute inset-0 h-full w-full"
                  viewBox={`0 0 ${chartData.length * 50} 100`}
                  preserveAspectRatio="none"
                >
                  <polyline
                    points={chartData
                      .map((point, i) => {
                        const x = i * 50
                        const maxValue = Math.max(...chartData.map((d) => d.value))
                        const y = 100 - (point.value / maxValue) * 100
                        return `${x},${y}`
                      })
                      .join(" ")}
                    fill="none"
                    stroke="hsl(var(--primary))"
                    strokeWidth="2"
                  />
                </svg>

                {/* Eixo X (labels) */}
                <div className="absolute bottom-0 left-0 right-0 flex justify-between">
                  {chartData
                    .filter((_, i) => i % Math.ceil(chartData.length / 10) === 0)
                    .map((point, i) => (
                      <div key={i} className="text-xs text-muted-foreground">
                        {point.label}
                      </div>
                    ))}
                </div>
              </div>
            ) : (
              <div className="h-full flex items-end justify-between">
                {chartData.map((point, i) => {
                  const maxValue = Math.max(...chartData.map((d) => d.value))
                  const height = (point.value / maxValue) * 100

                  return (
                    <div key={i} className="flex flex-col items-center">
                      <div className="w-8 bg-primary rounded-t" style={{ height: `${height}%` }} />
                      <div className="text-xs mt-2 text-muted-foreground">{point.label}</div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

